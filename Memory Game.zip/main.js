let number = [];
let img = [];
let imgMemory = [];
let n = 4;
onload = () =>{
    start();
    createTable();
    setTimeout(imgFlip,1500);
};


const start = () =>{
    let k = x = 1;
    for(let i = 0; i<n*n;i++){
        k = k > n * 2 ? 1 : k;
        number[i] = k++;
    }
    
    for(let i = 0; i< n; i++){
        img[i] = [];
        imgMemory[i] = [];
        for(let j = 0; j< n; j++){
            x = Math.floor(Math.random() * number.length);
            img[i][j] = number[x];
            imgMemory[i][j] = number[x];
            number.splice(x,1);
        }
    }
};

const createTable = () =>{

    let view = '';

    for(let i = 0; i<n;i++){
        view += `<tr>`;
        for(let j = 0; j<n;j++){
            view += `<td>
                        <img onclick="clickImg(${i},${j})" src="img/${img[i][j]}.png" />
                    </td>`;
        }
        view += `</tr>`;
    }
    document.getElementsByTagName("table")[0].innerHTML = view;
};



const imgFlip = ()=>{
    for(let i = 0; i<n;i++){
        for(let j = 0; j<n;j++){
            img[i][j] = 0;
        }
    }
    createTable();
};


const clickImg = (i,j) =>{
    img[i][j] = imgMemory[i][j];
    createTable();
};